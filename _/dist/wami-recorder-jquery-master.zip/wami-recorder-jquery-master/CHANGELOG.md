## 2.0.0 (2014-12-14)

New Features:

  - ogg/mp3 conversion

## 1.1.3 (2014-12-01)

Bugfixes:

  - replaced die()

## 1.1.2 (2014-11-09)

Bugfixes:

  - Corrected || operator
  - Removed newline Character warning

## 1.1.1 (2014-07-02)

Features:

  - JQuery libraries moved to Google CDN
  - Changelog Added
  - Jquery Updated to 2.1.1
