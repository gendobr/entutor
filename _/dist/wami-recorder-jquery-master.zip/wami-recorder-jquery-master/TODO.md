THIS is a pending Tasklist for wami-recorder-jquery

SERVER FILES:
- [X] ogg/mp3 conversion

CLIENT FILES:
- [ ] index.html variable cleanup
- [ ] recorder.js code revision
- [ ] getUserMedia/Stream API HTML5 compatibility
