# Audio Recorder

This is a code snippet/example for using RecorderJS with the web audio input feature to record audio from
[Web Audio API](https://dvcs.w3.org/hg/audio/raw-file/tip/webaudio/specification.html).  

Hosted live on [Web Audio Demos](http://webaudiodemos.appspot.com/AudioRecorder/index.html).
Check it out, feel free to fork, submit pull requests, etc.

-Chris
